import React, { Component } from 'react';
import './App.css';

import Header from './pages/Header';
import ListaFilmes from './pages/ListaFilmes';


class App extends Component {
  
  
  render() {
    return (
      <div className="App">
        <Header />
        <ListaFilmes />
      </div>
    );
  }
}

export default App;
