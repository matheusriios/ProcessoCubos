import React, { Component } from 'react';
import '../App.css';
import '../public/js';
import api from '../service/api';

//Components
import Modal from './Modal'


class ListaFilmes extends Component {
  constructor(props){
    super(props)

    this.state = {
      dadosFilme: [], 
      dadosFilmeAux: [], 
      modalIsOpen: false,
      idFilme: '',
      genereosFilmeModal: [],
      language: []
    }       
  }
  
  componentDidMount(){
    this.carregarApi() 
    this.filtarFilmes()     
  }

  carregarApi = async () => {
    const response = await api.get('https://api.themoviedb.org/3/discover/movie?api_key=2856e9bcfec8f9fcd19c0bebb2688fa9');
    const data  = response.data;
    
    const arrayFilmeAux = [];

    data.results.forEach(async (filme) => {      
      let varAux = await api.get(`https://api.themoviedb.org/3/movie/${filme.id}?api_key=2856e9bcfec8f9fcd19c0bebb2688fa9`)
      arrayFilmeAux.push(varAux.data);
      
      this.setState({
        dadosFilme: await arrayFilmeAux,
        dadosFilmeAux: await arrayFilmeAux
      });
    });          
    
    return arrayFilmeAux
  }

  inputBuscaFilmes = () => {
    return (
      <form className="content-input-filtrar-filmes">          
          <input type="text" onInput={(e) => this.filtarFilmes(e.target.value)} placeholder="Busque um filme por nome, ano ou gênero" />                    
      </form>              
    )
  }

  showModal = (dados) => {    
    const genereosFilmeModal = [];    
    dados.genres.map(dados => genereosFilmeModal.push(dados))    
    this.setState({modalIsOpen: true, idFilme: dados.id, genereosFilmeModal: genereosFilmeModal, language: dados.spoken_languages});         
  }

  hideModal = () =>  {
    this.setState({modalIsOpen: false});
  }

  filtarFilmes = (text) => {
    const {dadosFilme, dadosFilmeAux}   = this.state
    const arrayFilmesAux = dadosFilmeAux;

    
    
    if(text !== undefined){      
      if(text.length > 0){                
        const newFilme = dadosFilme.filter(filme => {                    
          const filmeFiltado = `${filme.title} ${filme.genres.map(genre => genre.name)}`;          
          const dadosInput   = text;                    
          return filmeFiltado.indexOf(dadosInput) >= 0;                    
        })
                
        return this.setState({
          dadosFilme: newFilme
        })
      }      
    }        
    this.setState({
      dadosFilme: arrayFilmesAux
    })

  }

  containerConteudoFilmes = (dados, index) => {     
    return(      
      <article key={index} className="w-100 d-flex justify-content">
        <div className="container-conteudo-filmes">
          <div className="container-divide-box">
              <div className="container-image-filme">              
                <img alt="Imagem Filme" src={`https://image.tmdb.org/t/p/w600_and_h900_bestv2/${dados.backdrop_path}`}/>
              </div>

              <div className="container-title-data-descricao w-100">
                <div className="container-title">
                  <button onClick={() => this.showModal(dados)} className="w-100 button-title-filme">
                    <h1>{dados.title}</h1>
                  </button>
                </div>

                <div className="container-data">
                  <p>{dados.release_date}</p>
                </div>

                <div className="container-descricao">
                  <p>{dados.overview}</p>
                </div>

                <div className="container-genero">
                  <div className="d-flex">
                    {dados.genres.map((dados, index) => <p key={index}>{dados.name}</p>)}
                  </div>
                </div>
              </div>

              <div className="container-aprovacao">
                <div className="container-content-aprovacao">
                  <span>{dados.vote_average * 10}%</span>
                </div>
              </div>
          </div>
        </div>        
        
      </article>    
    )
  }
  
  
  render() {
    const {dadosFilme} = this.state          
    return (
      <section className="App">
        <div className="container-input-filtrar-filmes">  
          {this.inputBuscaFilmes()}         
        </div>
        <section>
          { dadosFilme.map((dados, index) => this.containerConteudoFilmes(dados, index)) } 
          {this.state.modalIsOpen ? <Modal language={this.state.language} genereosFilmeModal={this.state.genereosFilmeModal} idFilme={this.state.idFilme} show={this.state.modalIsOpen} handleClose={this.hideModal}></Modal> : null}       
        </section>        
      </section>
    );
  }
}

export default ListaFilmes;

