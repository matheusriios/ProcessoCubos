import React, {Component} from 'react'
import api from '../service/api'



class Modal extends Component{
  constructor(props){
    super(props)

    this.state = {
      dadosFilme: []
    }
  }

  componentDidMount(){
    this.carregarApi()
  }
  
  carregarApi = async () => {
    const {idFilme} = this.props;    
    const response = await api.get(`https://api.themoviedb.org/3/movie/${idFilme}?api_key=2856e9bcfec8f9fcd19c0bebb2688fa9`)    
    const dadosFilme = await response.data    
    this.setState({
      dadosFilme: dadosFilme
    });
  }

  render(){    
    const {show, handleClose, genereosFilmeModal, language} = this.props;
    const {dadosFilme} = this.state                

    const showHideClassName = show ? "modal display-block" : "modal display-none";            
    return(
      <div className={showHideClassName}>
        <section className="modal-main">    
          <div className="container-modal">
            <div className="container-title-data-modal">
                <div className="container-title-modal">
                  <h1>{dadosFilme.title}</h1>
                </div>
                <div className="container-data-modal">
                  <span>{dadosFilme.release_date}</span>
                </div>
            </div>

            <div className="container-descricoes-img-modal">
                <div className="container-descricao-modal">
                  <div className="container-sinopse-modal">
                    <h3 className="title-sinopse-informacoes">Sinopse</h3>
                    <p>{dadosFilme.overview}</p>
                  </div>

                  <div className="container-sinopse-modal">
                    <h3 className="title-sinopse-informacoes">Informações</h3>                  
                    <div className="container-informacoes-modal">
                      <div className="informacoes-modal">
                        <h3>Situação</h3>
                        <p>{dadosFilme.status}</p>
                      </div>
                      <div className="informacoes-modal">
                        <h3>Idioma</h3>
                        {language.map((language, index) => <p key={index}>{language.name}</p>)}
                      </div>
                      <div className="informacoes-modal">
                        <h3>Duração</h3>
                        <p>{parseFloat(dadosFilme.runtime / 60).toFixed(2).replace('.', ':')}</p>
                      </div>
                      <div className="informacoes-modal">
                        <h3>Orçamento</h3>
                        <p>R${dadosFilme.budget}</p>
                      </div>
                      <div className="informacoes-modal">
                        <h3>Receita</h3>
                        <p>R${dadosFilme.revenue}</p>
                      </div>
                      <div className="informacoes-modal">
                        <h3>Lucro</h3>
                        <p>{dadosFilme.revenue - dadosFilme.budget}</p>
                      </div>
                    </div>
                  </div>

                  <div className="container-gereno-modal">
                    <div className="container-content-gereno-modal">                    
                      {genereosFilmeModal.map((dados, index) => <p key={index}>{dados.name}</p>)}
                    </div>
                  </div>
                </div>
                <div className="container-img-modal">
                  <img alt="Imagem Filme" src={`https://image.tmdb.org/t/p/w600_and_h900_bestv2/${dadosFilme.backdrop_path}`}/>
                </div>
            </div>

            <div className="container-aprovacao-modal">
                <div className="container-content-aprovacao-modal">
                  <span>{dadosFilme.vote_average * 10}%</span>
                </div>
              </div>

            <div className="closeMenu" onClick={handleClose}>
              <span>X</span>
            </div>
          </div>
        </section>
      </div>
    )
  }
}


export default Modal