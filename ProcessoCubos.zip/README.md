This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Tecnologias que deverá estar instaladas em sua máquina
> NodeJS
> ReactJS

## Scripts Disponíveis
No diretório do projeto, você pode executar:

## 'npm init'
Instala todas as dependências que o web app necessitará para sua execução

### `npm start`
Executa o aplicativo no modo de desenvolvimento. <br>
Abra [http: // localhost: 3000] (http: // localhost: 3000) para visualizá-lo no navegador.

A página será recarregada se você fizer edições. <br>
Você também verá quaisquer erros de lint no console.

